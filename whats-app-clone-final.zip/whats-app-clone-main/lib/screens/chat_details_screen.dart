import 'package:flutter/material.dart';
import 'package:whats_app_clone/models/chat_data_model.dart';
import 'package:whats_app_clone/models/message_model.dart';

class ChatDetailsScreen extends StatefulWidget {
  const ChatDetailsScreen({super.key, required this.chatData});
  final ChatDataModel chatData;

  @override
  State<ChatDetailsScreen> createState() => _ChatDetailsScreenState();
}

class _ChatDetailsScreenState extends State<ChatDetailsScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  late List<MessageModel> _messages;

  @override
  void initState() {
    super.initState();
    _messages = [
      MessageModel(
        text: "السلام عليكم! كيف حالك؟",
        time: "10:00",
        isSentByMe: false,
      ),
      MessageModel(
        text: "وعليكم السلام، الحمد لله بخير، وأنت؟",
        time: "10:01",
        isSentByMe: true,
      ),
      MessageModel(
        text: "بخير الحمد لله 😊 ماذا تفعل اليوم؟",
        time: "10:02",
        isSentByMe: false,
      ),
      MessageModel(
        text: "أعمل على مشروع Flutter جديد، يبدو رائعًا!",
        time: "10:05",
        isSentByMe: true,
      ),
      MessageModel(
        text: "ممتاز! Flutter رائع فعلًا 🚀",
        time: "10:06",
        isSentByMe: false,
      ),
      MessageModel(
        text: "نعم، وأنا أبني واجهة شبيهة بواتساب الآن",
        time: "10:08",
        isSentByMe: true,
      ),
      MessageModel(
        text: "هل يمكنني مشاهدتها عند الانتهاء؟",
        time: "10:09",
        isSentByMe: false,
      ),
      MessageModel(
        text: "بالتأكيد! سأرسل لك رابط المشروع قريبًا 👍",
        time: "10:10",
        isSentByMe: true,
      ),
    ];
  }

  void _sendMessage() {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    final now = TimeOfDay.now();
    final timeStr =
        "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";

    setState(() {
      _messages.add(MessageModel(
        text: text,
        time: timeStr,
        isSentByMe: true,
      ));
      _messageController.clear();
    });

    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1418),
      appBar: _buildAppBar(context),
      body: Column(
        children: [
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Color(0xFF0D1418),
              ),
              child: ListView.builder(
                controller: _scrollController,
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  return _buildMessageBubble(_messages[index]);
                },
              ),
            ),
          ),
          _buildInputBar(),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: const Color(0xFF1F2C34),
      leadingWidth: 30,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: Colors.white),
        onPressed: () => Navigator.pop(context),
        padding: EdgeInsets.zero,
      ),
      title: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundImage: AssetImage(widget.chatData.imagePath),
            backgroundColor: Colors.grey,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  widget.chatData.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Text(
                  "متصل الآن",
                  style: TextStyle(
                    color: Color(0xFF25D366),
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.call, color: Colors.white, size: 22),
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("جاري الاتصال..."),
                backgroundColor: Color(0xFF25D366),
                duration: Duration(seconds: 1),
              ),
            );
          },
        ),
        IconButton(
          icon: const Icon(Icons.videocam, color: Colors.white, size: 24),
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("جاري بدء مكالمة الفيديو..."),
                backgroundColor: Color(0xFF25D366),
                duration: Duration(seconds: 1),
              ),
            );
          },
        ),
        PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert, color: Colors.white, size: 22),
          color: const Color(0xFF233138),
          onSelected: (value) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(value),
                backgroundColor: const Color(0xFF1F2C34),
                duration: const Duration(seconds: 1),
              ),
            );
          },
          itemBuilder: (context) => const [
            PopupMenuItem(
              value: "عرض جهة الاتصال",
              child: Text(
                "عرض جهة الاتصال",
                style: TextStyle(color: Colors.white),
              ),
            ),
            PopupMenuItem(
              value: "البحث في المحادثة",
              child: Text(
                "البحث في المحادثة",
                style: TextStyle(color: Colors.white),
              ),
            ),
            PopupMenuItem(
              value: "كتم الإشعارات",
              child: Text(
                "كتم الإشعارات",
                style: TextStyle(color: Colors.white),
              ),
            ),
            PopupMenuItem(
              value: "مسح المحادثة",
              child: Text(
                "مسح المحادثة",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildMessageBubble(MessageModel message) {
    final bool isMine = message.isSentByMe;

    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(
          bottom: 6,
          right: isMine ? 4 : 60,
          left: isMine ? 60 : 4,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isMine ? const Color(0xFF005C4B) : const Color(0xFF1F2C34),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft:
                isMine ? const Radius.circular(16) : const Radius.circular(4),
            bottomRight:
                isMine ? const Radius.circular(4) : const Radius.circular(16),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment:
              isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              message.text,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 15,
              ),
              textDirection: TextDirection.rtl,
            ),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  message.time,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.6),
                    fontSize: 11,
                  ),
                ),
                if (isMine) ...[
                  const SizedBox(width: 4),
                  const Icon(
                    Icons.done_all,
                    size: 14,
                    color: Color(0xFF53BDEB),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      color: const Color(0xFF1F2C34),
      child: Row(
        children: [
          ValueListenableBuilder<TextEditingValue>(
            valueListenable: _messageController,
            builder: (context, value, child) {
              final hasText = value.text.trim().isNotEmpty;
              return GestureDetector(
                onTap: hasText ? _sendMessage : null,
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: const BoxDecoration(
                    color: Color(0xFF25D366),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    hasText ? Icons.send : Icons.mic,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
              );
            },
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF2A3942),
                borderRadius: BorderRadius.circular(25),
              ),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.emoji_emotions_outlined,
                        color: Colors.white54, size: 22),
                    onPressed: () {},
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    constraints: const BoxConstraints(),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      style:
                          const TextStyle(color: Colors.white, fontSize: 15),
                      textDirection: TextDirection.rtl,
                      maxLines: 5,
                      minLines: 1,
                      decoration: const InputDecoration(
                        hintText: "رسالة",
                        hintStyle: TextStyle(color: Colors.white38),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                            vertical: 10, horizontal: 4),
                        hintTextDirection: TextDirection.rtl,
                      ),
                      cursorColor: const Color(0xFF25D366),
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.attach_file,
                        color: Colors.white54, size: 22),
                    onPressed: () => _showAttachmentOptions(context),
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    constraints: const BoxConstraints(),
                  ),
                  IconButton(
                    icon: const Icon(Icons.camera_alt_outlined,
                        color: Colors.white54, size: 22),
                    onPressed: () {},
                    padding: const EdgeInsets.only(right: 8),
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showAttachmentOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF233138),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _attachmentOption(
                      Icons.insert_drive_file, Colors.indigo, "ملف"),
                  _attachmentOption(Icons.camera_alt, Colors.pink, "كاميرا"),
                  _attachmentOption(Icons.image, Colors.purple, "معرض"),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _attachmentOption(Icons.headphones, Colors.orange, "صوت"),
                  _attachmentOption(Icons.location_on, Colors.teal, "موقع"),
                  _attachmentOption(
                      Icons.person, Colors.cyan, "جهة اتصال"),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _attachmentOption(IconData icon, Color color, String label) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: Colors.white, size: 26),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(color: Colors.white, fontSize: 13),
          ),
        ],
      ),
    );
  }
}
